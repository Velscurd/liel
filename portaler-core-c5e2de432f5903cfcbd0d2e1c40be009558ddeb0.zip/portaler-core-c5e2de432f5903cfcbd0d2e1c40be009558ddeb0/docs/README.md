# Docs

Individual setups are below.

- [Setting up for Development](./devsetup.md)
- [Self Hosting](./selfhosting.md)
- [Discord Setup](./discord.md)
