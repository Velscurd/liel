declare namespace Express {
  export interface Request {
    userId: number
    serverId: number
    isPublic: boolean
  }
}
