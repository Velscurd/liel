# Portaler Frontend

Built using Typescript, Create React App, Redux, Material UI, and Cytoscape.js

There is no Redux Async middleware and all actions are dispatched from custom hooks.
