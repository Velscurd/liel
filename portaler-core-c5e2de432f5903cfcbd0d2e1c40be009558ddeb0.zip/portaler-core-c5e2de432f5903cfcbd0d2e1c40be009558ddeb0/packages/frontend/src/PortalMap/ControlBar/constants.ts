const fontSize = 20

export { fontSize }
