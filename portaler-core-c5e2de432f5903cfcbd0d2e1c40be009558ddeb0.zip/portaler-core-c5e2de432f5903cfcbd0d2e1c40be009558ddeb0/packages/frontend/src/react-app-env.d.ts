/// <reference types="react-scripts" />
declare module 'cytoscape-cose-bilkent'
