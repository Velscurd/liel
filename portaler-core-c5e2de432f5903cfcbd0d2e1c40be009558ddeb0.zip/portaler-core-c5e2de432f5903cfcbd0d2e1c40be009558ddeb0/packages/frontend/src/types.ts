export interface InputError {
  fieldName: string
  errorText: string
}
